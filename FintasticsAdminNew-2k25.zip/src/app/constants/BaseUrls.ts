export const baseUrl='https://www.fintastics.in/api/';
export const socket_baseUrl='https://www.fintastics.in/fintastics';
//live server

// export const baseUrl='http://192.168.1.3:3000/api/';
//local server

// export const baseUrl='https://www.fintastics.ai/api/';
// export const socket_baseUrl='https://www.fintastics.ai/fintastics';

