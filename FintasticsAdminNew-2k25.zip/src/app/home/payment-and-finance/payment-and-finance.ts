import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-and-finance',
  imports: [],
  templateUrl: './payment-and-finance.html',
  styleUrl: './payment-and-finance.scss'
})
export class PaymentAndFinance {

}
