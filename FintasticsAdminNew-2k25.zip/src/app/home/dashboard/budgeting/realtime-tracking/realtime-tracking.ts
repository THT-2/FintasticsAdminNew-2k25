import { Component } from '@angular/core';

@Component({
  selector: 'app-realtime-tracking',
  imports: [],
  templateUrl: './realtime-tracking.html',
  styleUrl: './realtime-tracking.scss'
})
export class RealtimeTracking {

}
