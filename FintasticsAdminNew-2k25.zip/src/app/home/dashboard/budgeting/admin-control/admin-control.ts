import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-control',
  imports: [],
  templateUrl: './admin-control.html',
  styleUrl: './admin-control.scss'
})
export class AdminControl {

}
