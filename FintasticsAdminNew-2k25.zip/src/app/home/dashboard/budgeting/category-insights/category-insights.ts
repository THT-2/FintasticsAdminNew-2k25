import { Component } from '@angular/core';

@Component({
  selector: 'app-category-insights',
  imports: [],
  templateUrl: './category-insights.html',
  styleUrl: './category-insights.scss'
})
export class CategoryInsights {

}
