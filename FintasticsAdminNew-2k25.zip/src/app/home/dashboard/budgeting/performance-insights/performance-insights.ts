import { Component } from '@angular/core';

@Component({
  selector: 'app-performance-insights',
  imports: [],
  templateUrl: './performance-insights.html',
  styleUrl: './performance-insights.scss'
})
export class PerformanceInsights {

}
