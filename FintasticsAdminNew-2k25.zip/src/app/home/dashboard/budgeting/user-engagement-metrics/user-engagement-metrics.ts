import { Component } from '@angular/core';

@Component({
  selector: 'app-user-engagement-metrics',
  imports: [],
  templateUrl: './user-engagement-metrics.html',
  styleUrl: './user-engagement-metrics.scss'
})
export class UserEngagementMetrics {

}
