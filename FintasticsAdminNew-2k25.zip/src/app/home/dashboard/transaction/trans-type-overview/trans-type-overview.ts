import { Component } from '@angular/core';

@Component({
  selector: 'app-trans-type-overview',
  imports: [],
  templateUrl: './trans-type-overview.html',
  styleUrl: './trans-type-overview.scss'
})
export class TransTypeOverview {

}
