import { Component } from '@angular/core';

@Component({
  selector: 'app-categories-overview',
  imports: [],
  templateUrl: './categories-overview.html',
  styleUrl: './categories-overview.scss'
})
export class CategoriesOverview {

}
