import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-categories',
  imports: [],
  templateUrl: './blog-categories.html',
  styleUrl: './blog-categories.scss'
})
export class BlogCategories {

}
