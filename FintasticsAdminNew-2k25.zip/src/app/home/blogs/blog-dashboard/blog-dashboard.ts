import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-blog-dashboard',
  imports: [RouterLink],
  templateUrl: './blog-dashboard.html',
  styleUrl: './blog-dashboard.scss'
})
export class BlogDashboard {

}
