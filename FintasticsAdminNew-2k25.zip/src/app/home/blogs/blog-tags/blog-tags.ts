import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-tags',
  imports: [],
  templateUrl: './blog-tags.html',
  styleUrl: './blog-tags.scss'
})
export class BlogTags {

}
