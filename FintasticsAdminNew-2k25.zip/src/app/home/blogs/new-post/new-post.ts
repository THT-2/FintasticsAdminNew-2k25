import { Component } from '@angular/core';

@Component({
  selector: 'app-new-post',
  imports: [],
  templateUrl: './new-post.html',
  styleUrl: './new-post.scss'
})
export class NewPost {

}
