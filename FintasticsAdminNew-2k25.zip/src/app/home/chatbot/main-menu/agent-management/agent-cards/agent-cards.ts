import { Component } from '@angular/core';
import { Filter } from "../../filter/filter";

@Component({
  selector: 'app-agent-cards',
  imports: [Filter],
  templateUrl: './agent-cards.html',
  styleUrl: './agent-cards.scss'
})
export class AgentCards {

}
