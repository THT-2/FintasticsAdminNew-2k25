import { Component } from '@angular/core';

@Component({
  selector: 'app-agent-performance',
  imports: [],
  templateUrl: './agent-performance.html',
  styleUrl: './agent-performance.scss'
})
export class AgentPerformance {

}
