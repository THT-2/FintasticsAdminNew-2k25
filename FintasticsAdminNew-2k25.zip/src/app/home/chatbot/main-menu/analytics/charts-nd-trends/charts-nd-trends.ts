import { Component } from '@angular/core';

@Component({
  selector: 'app-charts-nd-trends',
  imports: [],
  templateUrl: './charts-nd-trends.html',
  styleUrl: './charts-nd-trends.scss'
})
export class ChartsNdTrends {

}
