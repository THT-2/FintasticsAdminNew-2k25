import { Component } from '@angular/core';

@Component({
  selector: 'app-topic-analytics',
  imports: [],
  templateUrl: './topic-analytics.html',
  styleUrl: './topic-analytics.scss'
})
export class TopicAnalytics {

}
