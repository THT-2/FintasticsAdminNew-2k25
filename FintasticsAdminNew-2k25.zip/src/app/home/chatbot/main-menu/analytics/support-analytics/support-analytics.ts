import { Component } from '@angular/core';
import { Filter } from '../../filter/filter';

@Component({
  selector: 'app-support-analytics',
  imports: [Filter],
  templateUrl: './support-analytics.html',
  styleUrl: './support-analytics.scss'
})
export class SupportAnalytics {

}
