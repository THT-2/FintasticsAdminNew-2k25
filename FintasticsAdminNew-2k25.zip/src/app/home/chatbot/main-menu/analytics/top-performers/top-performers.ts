import { Component } from '@angular/core';

@Component({
  selector: 'app-top-performers',
  imports: [],
  templateUrl: './top-performers.html',
  styleUrl: './top-performers.scss'
})
export class TopPerformers {

}
