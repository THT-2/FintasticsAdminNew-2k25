import { Component } from '@angular/core';

@Component({
  selector: 'app-performance-details',
  imports: [],
  templateUrl: './performance-details.html',
  styleUrl: './performance-details.scss'
})
export class PerformanceDetails {

}
