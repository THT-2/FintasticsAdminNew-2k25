import { Component } from '@angular/core';

@Component({
  selector: 'app-chat-trends',
  imports: [],
  templateUrl: './chat-trends.html',
  styleUrl: './chat-trends.scss'
})
export class ChatTrends {

}
