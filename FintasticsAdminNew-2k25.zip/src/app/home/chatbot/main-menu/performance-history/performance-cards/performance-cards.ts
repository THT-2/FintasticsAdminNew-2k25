import { Component } from '@angular/core';
import { Filter } from '../../filter/filter';

@Component({
  selector: 'app-performance-cards',
  imports: [Filter],
  templateUrl: './performance-cards.html',
  styleUrl: './performance-cards.scss'
})
export class PerformanceCards {

}
