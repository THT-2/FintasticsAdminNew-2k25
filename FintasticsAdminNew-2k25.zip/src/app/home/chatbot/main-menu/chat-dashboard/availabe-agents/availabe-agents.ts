import { Component } from '@angular/core';

@Component({
  selector: 'app-availabe-agents',
  imports: [],
  templateUrl: './availabe-agents.html',
  styleUrl: './availabe-agents.scss'
})
export class AvailabeAgents {

}
