import { Component } from '@angular/core';

@Component({
  selector: 'app-repeat-users',
  imports: [],
  templateUrl: './repeat-users.html',
  styleUrl: './repeat-users.scss'
})
export class RepeatUsers {

}
