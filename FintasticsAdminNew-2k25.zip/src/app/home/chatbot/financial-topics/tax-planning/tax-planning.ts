import { Component } from '@angular/core';

@Component({
  selector: 'app-tax-planning',
  imports: [],
  templateUrl: './tax-planning.html',
  styleUrl: './tax-planning.scss'
})
export class TaxPlanning {

}
