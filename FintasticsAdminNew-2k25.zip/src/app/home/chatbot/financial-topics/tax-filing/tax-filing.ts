import { Component } from '@angular/core';

@Component({
  selector: 'app-tax-filing',
  imports: [],
  templateUrl: './tax-filing.html',
  styleUrl: './tax-filing.scss'
})
export class TaxFiling {

}
