import { Component } from '@angular/core';

@Component({
  selector: 'app-investment',
  imports: [],
  templateUrl: './investment.html',
  styleUrl: './investment.scss'
})
export class Investment {

}
