import { Component } from '@angular/core';

@Component({
  selector: 'app-wealth-management',
  imports: [],
  templateUrl: './wealth-management.html',
  styleUrl: './wealth-management.scss'
})
export class WealthManagement {

}
