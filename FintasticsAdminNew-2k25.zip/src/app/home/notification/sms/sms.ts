import { Component } from '@angular/core';
import { Card } from "../../../Z-Commons/card/card";
import { Table } from "../../../Z-Commons/table/table";

@Component({
  selector: 'app-sms',
  imports: [],
  templateUrl: './sms.html',
  styleUrl: './sms.scss'
})
export class Sms {

}
