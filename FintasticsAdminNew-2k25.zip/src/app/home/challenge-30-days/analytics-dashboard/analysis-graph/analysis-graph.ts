import { Component } from '@angular/core';

@Component({
  selector: 'app-analysis-graph',
  imports: [],
  templateUrl: './analysis-graph.html',
  styleUrl: './analysis-graph.scss'
})
export class AnalysisGraph {

}
