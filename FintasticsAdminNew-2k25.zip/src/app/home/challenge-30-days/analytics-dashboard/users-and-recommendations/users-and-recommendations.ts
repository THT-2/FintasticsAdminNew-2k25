import { Component } from '@angular/core';

@Component({
  selector: 'app-users-and-recommendations',
  imports: [],
  templateUrl: './users-and-recommendations.html',
  styleUrl: './users-and-recommendations.scss'
})
export class UsersAndRecommendations {

}
