import { Component } from '@angular/core';

@Component({
  selector: 'app-rewards-card',
  imports: [],
  templateUrl: './rewards-card.html',
  styleUrl: './rewards-card.scss'
})
export class RewardsCard {

}
