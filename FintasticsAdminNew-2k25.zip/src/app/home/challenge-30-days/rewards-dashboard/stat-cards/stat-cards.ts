import { Component } from '@angular/core';

@Component({
  selector: 'app-stat-cards',
  imports: [],
  templateUrl: './stat-cards.html',
  styleUrl: './stat-cards.scss'
})
export class StatCards {

}
