import { Component } from '@angular/core';

@Component({
  selector: 'app-challenge-30-days',
  imports: [],
  templateUrl: './challenge-30-days.html',
  styleUrl: './challenge-30-days.scss'
})
export class Challenge30Days {

}
