import { Component } from '@angular/core';

@Component({
  selector: 'app-previous-challenge-history',
  imports: [],
  templateUrl: './previous-challenge-history.html',
  styleUrl: './previous-challenge-history.scss'
})
export class PreviousChallengeHistory {

}
