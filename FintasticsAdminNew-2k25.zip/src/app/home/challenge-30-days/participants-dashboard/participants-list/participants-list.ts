import { Component } from '@angular/core';

@Component({
  selector: 'app-participants-list',
  imports: [],
  templateUrl: './participants-list.html',
  styleUrl: './participants-list.scss'
})
export class ParticipantsList {

}
