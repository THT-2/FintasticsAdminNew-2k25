import { Component } from '@angular/core';

@Component({
  selector: 'app-participant-cards',
  imports: [],
  templateUrl: './participant-cards.html',
  styleUrl: './participant-cards.scss'
})
export class ParticipantCards {

}
