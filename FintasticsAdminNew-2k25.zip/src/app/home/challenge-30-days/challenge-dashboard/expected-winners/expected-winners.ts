import { Component } from '@angular/core';

@Component({
  selector: 'app-expected-winners',
  imports: [],
  templateUrl: './expected-winners.html',
  styleUrl: './expected-winners.scss'
})
export class ExpectedWinners {

}
