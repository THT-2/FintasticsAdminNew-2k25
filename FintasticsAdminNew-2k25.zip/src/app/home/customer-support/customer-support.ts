import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-support',
  imports: [],
  templateUrl: './customer-support.html',
  styleUrl: './customer-support.scss'
})
export class CustomerSupport {

}


